window.onload=function(){
	// 购买接口
	// 单人购买
	// 支付接口
	// 拼团购买
	function pershop(){
		var url = window.location.href;
		var num=url.indexOf("=")+1;
		var id=url.slice(num,url.length);	
		$(".zhiShop1").click(function(){
			if(localStorage.getItem("tishi")){
					$.ajax({
						url:"http://s.coolndns.com/pay",
						type:"post",
						data:{
							column_id:id,
							group_master_id:localStorage.getItem("user_id"),
							is_group:localStorage.getItem("pintuan"),
							token:localStorage.getItem("token")
						},
						success(res){
							if(res){
								window.open("zhifubao.html"+"?id="+id)	
							}
						}
					})
			}else{
				alert("请先登录！在购买！")
			}
		})
	}
	pershop()
	// 单人购买接口
	function shopping(){
		var url = window.location.href;
		var num=url.indexOf("=")+1;
		var id=url.slice(num,url.length);
			$(".zhiShop").click(function(){
				if(localStorage.getItem("tishi")){
						$.ajax({
							url:"http://s.coolndns.com/pay",
							type:"post",
							data:{
								column_id:id,
								group_master_id:localStorage.getItem("user_id"),
								is_group:localStorage.getItem("pintuan"),
								token:localStorage.getItem("token")
							},
							success(res){
								if(res){
									window.open("zhifubao.html"+"?id="+id)	
								}
							}
						})
				}else{
					alert("请先登录！在购买！")
				}
			})
	}
	shopping() 
	if(localStorage.getItem("tuanend")=="1"){
	    $(".pintuan").mouseenter(function(){
			$(".pingshares").remove();
		});
		$(".pintuan").css("background-color","#000");    	
    }
}