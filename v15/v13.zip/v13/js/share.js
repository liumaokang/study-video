$(function(){
    // // 分享到QQ空间
    // $("#shareSpace").click(function(){
    //     var url=localStorage.getItem("goods")
    //      if(localStorage.getItem("tishi")){
    //          //分享到QQ空间
    //          var user_id=localStorage.getItem("user_id")
    //          // console.log(user_id)
    //          var url=localStorage.getItem("goods")
    //         function ShareTip(title,url,picurl){
    //           var shareqqzonestring='http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?summary='+title+'&url='+url+'&pics='+picurl;
    //           window.open(shareqqzonestring);
    //         }

    //         ShareTip("或者点击翻页按钮，点击 马上体验，可以体验故事，同时在触屏上也有很好的体验效果奥，地图故事，尽在书中，赶快体验吧，建议使用对 HTML5支持较好的浏览器",url,"http://tm.arcgisonline.cn:8038/App101/MapstoryBook/css/Img/ShareBook.jpg");
    //      }else{
    //         alert("请先登录在分享")
    //     }
    // }) 
    // 分享给QQ好友
       var user_id=localStorage.getItem("user_id")
        var urls=window.location.href+"&user_id="+user_id;
        var covers=localStorage.getItem("imgs")
        $("#qq_id").click(function(){
            if(localStorage.getItem("tishi")){              
                var p = {
                    url : urls, /*获取URL，可加上来自分享到QQ标识，方便统计*/
                    desc:'',
                    //title : '新玩法，再不来你就out了！', /*分享标题(可选)*/
                    title:'',
                    summary : '', /*分享摘要(可选)*/
                    pics : covers, /*分享图片(可选)*/
                    flash : '', /*视频地址(可选)*/
                    site : ""好学堂, /*分享来源(可选) 如：QQ分享*/
                    style : '201',
                    width : 32,
                    height : 32
                };

                var s = [];
                for ( var i in p) {
                    s.push(i + '=' + encodeURIComponent(p[i] || ''));
                }

                var url = "http://connect.qq.com/widget/shareqq/index.html?"+s.join('&');

                // return url;
                window.location.href =url;
                //document.write(['<a class="qcShareQQDiv" href="http://connect.qq.com/widget/shareqq/index.html?',s.join('&'), '" >分享给QQ好友</a>' ].join(''));
            // }
            }else{
                alert("请先登录在分享")
            }
      })
        // 微信分享 
    	$(".wx").click(function(){            
             if(localStorage.getItem("tishi")){
                var url=window.location.href
                var target_url =url+"&user_id="+user_id;
                window.open(target_url, 'weixin',"weixin");
              }else{
                  alert("请先登录在分享")
               }
    	})      
  


})