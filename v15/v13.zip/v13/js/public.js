window.onload=function(){
	var localurl=window.location.href;//本地路径
	var a=localurl.lastIndexOf('/')
	var urlWeb=localurl.slice(0,a)
	// 导航栏
	function getnav(){
		$.ajax({
			url:"http://s.coolndns.com/navigation",
			type:"get",
			success(res){
				var newArra=JSON.parse(res).data
				var ulList=$("#index")[0];
				for(let i=0;i<newArra.length;i++){	
					var metas=$(".indexTitle").clone(true)[0];
					ulList.append(metas);//qppendTo和append的区别，动态添加导航标题
					var liList=$("#index>li");
					liList.eq(i).find("a").text(newArra[i].name)
				}
				liList.eq(0).find("a").attr("href","index.html")
				liList.eq(1).find("a").attr("href","allobjects.html")
				liList.eq(2).find("a").attr("href","techers.html")
				localStorage.setItem('title',JSON.stringify(newArra));			
			}
		})
	}
	// getnav();
	// 栏目模块
	function columns(){
		$.ajax({
			url:"http://s.coolndns.com/column",
	     	type:"get",
			success(res){
				var date=res.data;
				var	liList=$(".liList>li")[0];
				for(let i=0;i<date.length;i++){
					var imgs=date[i].cover;
					var price=date[i].price;
					var name=date[i].name;
					var ID=date[i].id;
					var divs=$(".inds").clone(true)[0];
					liList.append(divs)
					var divnews=$(".liList>li>div")
					divnews.attr("class","ind")
					divnews.eq(i).find("#images").attr("src",imgs)
					divnews.eq(i).find(".biaoti>span").text(name)
					if(date[i].price=="0"){
						divnews.eq(i).find(".biaoti>a").text("观看")
					}else{
						divnews.eq(i).find(".biaoti>a").text("付费")
					}
					divnews.eq(i).find(".biaoti>a").click(function(){
						if(date[i].price=="0"){
							location.href=urlWeb+"/video-details.html"+"?id="+date[i].id
						}else{						
							location.href=urlWeb+"/weiqi-guidance.html"+"?id="+date[i].id;
						}
					})
				}

			}
		})
	}
	columns();
	// 控制首页栏目状态
	function control(){
			$.ajax({
			url:"http://s.coolndns.com/homepage",
			data:{},
			type:"get",
			success(res){
				var date=JSON.parse(res).data;	
				var columns=$(".column");
				var arra=[];
				for(let i=0;i<date.length;i++){
						var status=date[i].status;
						if(date[i].status=="1"){	
							columns[i].innerHTML=date[i].name;
							arra[arra.length]=date;
							$(".column").eq(i).closest(".w").css("display","block")
						}
						if(date[i].status=="0"){
							$(".column").eq(i).closest(".w").css("display","none")
					}
				}
			}
		})
	}
	control();
	//动态信息-新闻列表业
	function indexnewsdetails(){
		$.ajax({
			url:"http://s.coolndns.com/articles",
			data:{
				limit:2,
				page:1,
				count:1,
				styles:2
			},
			success(res){
				var date=JSON.parse(res).data;
				var uls=$("#indexStatus");
				for(let i=0;i<date.length;i++){
					var lifirsted=$(".indexliList").clone(true);
					uls.append(lifirsted)
					lifirsted.attr("class","")
					var newslist=$("#indexStatus li")
					newslist.eq(i).find("img").attr("src",date[i].cover)
					newslist.eq(i).find(".newsmain").text(date[i].content)		
					newslist.eq(i).find(".look").click(function(){
						location.href=urlWeb+"/normal-news.html"+"?id="+date[i].id;
					})
					newslist.eq(date.length).remove()
				}
				
			}
		})
	}	
	indexnewsdetails()
	// 教师团队
	function techersSteam(){
		$.ajax({
			url:"http://s.coolndns.com/articles",
			data:{
				limit:2,
				page:1,
				count:1,
				styles:6
			},
			success(res){
				var date=JSON.parse(res).data
				var uls=$("#teacher_img");
				for(let i=0;i<date.length;i++){
					var lifirsted=$(".teacher-img").clone(true);
					uls.append(lifirsted)
					lifirsted.attr("class","")
					var newslist=$("#teacher_img li")
					newslist.eq(i).find("img").attr("src",date[i].cover)
					newslist.eq(i).find(".teacher_name").text(date[i].title)		
					newslist.eq(i).find("a").click(function(){
						location.href=urlWeb+"/teacher-details.html"+"?id="+date[i].id;
					})
					newslist.eq(date.length).remove()
				}
				
			}
		})
	}	
	techersSteam()
	

	// 热点咨询
	function hostasked(){
		$.ajax({
			url:"http://s.coolndns.com/articles",
			data:{
				limit:2,
				page:1,
				count:1,
				styles:3
			},
			success(res){
				var date=JSON.parse(res).data;
				// console.log(date)
				var ols=$(".slide>ul");
				// console.log(ols)
				for(let i=0;i<date.length;i++){
					var lifirsted=$(".hotas").clone(true);
					ols.append(lifirsted)
					lifirsted.attr("class","")
					// console.log(date[i].title)
					var newslist=$(".slide>ul li")
					newslist.eq(i).find(".stu").text(date[i].title)			
					newslist.eq(i).find("img").attr("src",date[i].cover)			
					newslist.eq(i).click(function(){
						location.href=urlWeb+"/normal-news.html"+"?id="+date[i].id;
					})
					newslist.eq(date.length).remove()
				}	
			}
		})
	}	
	hostasked()
	// 精选视频
	function selectvideo(){
		$.ajax({
			url:"http://s.coolndns.com/articles",
			data:{
				limit:2,
				page:1,
				count:1,
				styles:3
			},
			success(res){
				var date=JSON.parse(res).data;
				// console.log(date)
				var ols=$(".slide>ul");
				// console.log(ols)
				for(let i=0;i<date.length;i++){
					var lifirsted=$(".hotas").clone(true);
					ols.append(lifirsted)
					lifirsted.attr("class","")
					// console.log(date[i].title)
					var newslist=$(".slide>ul li")
					newslist.eq(i).find(".stu").text(date[i].title)			
					newslist.eq(i).find("img").attr("src",date[i].cover)			
					newslist.eq(i).click(function(){
						location.href=urlWeb+"/normal-news.html"+"?id="+date[i].id;
					})
					newslist.eq(date.length).remove()
				}	
			}
		})
	}	
	// selectvideo()
}